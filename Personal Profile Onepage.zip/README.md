
  # Personal Profile Onepage

  This is a code bundle for Personal Profile Onepage. The original project is available at https://www.figma.com/design/wuJiXhtpAMqvFuPL5W0Z2W/Personal-Profile-Onepage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  